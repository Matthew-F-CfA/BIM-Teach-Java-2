class NumberNotation {

  public static void main(String args[]) {
    double dbl=Double.valueOf("2E1").doubleValue();
    System.out.println(dbl);
  }
}