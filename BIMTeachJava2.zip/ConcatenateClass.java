class ConcatenateClass {

  public static void main(String args[]) {
    int intNumber=123;
    int intNumber2=4;
    System.out.println(intNumber+""+intNumber2+" is the number.");
  }
}