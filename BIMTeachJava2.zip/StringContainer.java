package bim.data;

class StringContainer {
  String strStr;

  public static void main(String args[]) {
    StringContainer strContainer=new StringContainer("Testing");

    System.out.println(strContainer.getString());
  }

  StringContainer() {
  }

  StringContainer(String strStr) {
    this.strStr=strStr;
  }

  public String getString() {
    return strStr;
  }

  public void setString(String strStr) {
    this.strStr=strStr;
  }
}